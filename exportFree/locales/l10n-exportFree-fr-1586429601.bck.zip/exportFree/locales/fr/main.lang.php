<?php
// Language: Français 
// Module: exportFree - 0.8.0-dev-r0073
// Date: 2020-04-09 10:41:52 
// Translated with dcTranslater - 2020.04.09 

#inc/class.dc.export.flat.Free.php:27
$GLOBALS['__l10n']['Flat file export for Free'] = 'Export "a plat" pour Free';

#inc/class.dc.import.flat.Free.php:20
$GLOBALS['__l10n']['Import Flat files folder'] = 'Importer un dossier de fichiers a plat';

#inc/class.dc.import.flat.Free.php:21
$GLOBALS['__l10n']['Import a blog or a full install Dotclear from a flat files folder.'] = 'Importer un blog ou une installation complete depuis un dossier de fichiers a plat';

#inc/class.dcPluginHelper.php:85
#inc/class.exportFree.php:64
$GLOBALS['__l10n']['Unable to save the configuration'] = 'Impossible de sauver la configuration';

#inc/class.dcPluginHelper.php:88
#inc/class.exportFree.php:67
$GLOBALS['__l10n']['Redirection not found'] = 'Redirection introuvable';

#inc/class.dcPluginHelper.php:112
$GLOBALS['__l10n']['%s plugin is not configured.'] = 'Le plugin %s n\'est pas configuré';

#inc/class.dcPluginHelper.php:122
$GLOBALS['__l10n']['Unable to save the code'] = 'Impossible de sauver le code';

#inc/class.dcPluginHelper.php:332
$GLOBALS['__l10n']['Scope'] = 'Domaine d\'application';

#inc/class.dcPluginHelper.php:334
$GLOBALS['__l10n']['Go'] = 'Aller';

#inc/class.dcPluginHelper.php:336
$GLOBALS['__l10n']['Select the blog in which parameters apply'] = 'Sélectionnez le blog auquel s\'applique les paramètres';

#inc/class.dcPluginHelper.php:337
$GLOBALS['__l10n']['Update global options'] = 'Mise à jour des options globales';

#inc/class.dcPluginHelper.php:349
$GLOBALS['__l10n']['Enable %s on this blog'] = 'Activer %s pour ce blog';

#inc/class.dcPluginHelper.php:351
$GLOBALS['__l10n']['Enable the plugin on this blog.'] = 'Activer le plugin pour ce blog';

#inc/class.dcPluginHelper.php:381
$GLOBALS['__l10n']['%s menu not present.'] = 'le menu %s est absent';

#inc/class.dcPluginHelper.php:425
$GLOBALS['__l10n']['icon plugin'] = 'Icone';

#inc/class.dcPluginHelper.php:428
$GLOBALS['__l10n']['Author(s)'] = 'Auteur(s)';

#inc/class.dcPluginHelper.php:657
$GLOBALS['__l10n']['The folder is not in the var directory'] = 'Le dossier ne se trouve pas dans le répertoire VAR';

#inc/class.dcPluginHelper.php:661
$GLOBALS['__l10n']['Creating a var directory failed'] = 'La creation du répertoire VAR a échoué';

#inc/class.exportFree.php:16
$GLOBALS['__l10n']['Export Free'] = 'Export pour Free';

#inc/class.exportFree.php:17
$GLOBALS['__l10n']['Export your blog for Free'] = 'Exportez votre blog (Free)';

#inc/lib.export.Free.maintenance.php:24
#inc/lib.export.Free.maintenance.php:79
$GLOBALS['__l10n']['Database export for Free website'] = 'Exporter la base de données (Free)';

#inc/lib.export.Free.maintenance.php:25
$GLOBALS['__l10n']['Download database of current blog for Free website'] = 'Télécharger les contenus et réglages du blog courant (Free)';

#inc/lib.export.Free.maintenance.php:80
$GLOBALS['__l10n']['Download database of all blogs for Free website'] = 'Télécharger les contenus et réglages de tous les blogs (Free)';

?>